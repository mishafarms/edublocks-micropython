# EduBlocks MicroPython (ESP32)

Experiment build of EduBlocks designed for the ESP32.

## Build

    yarn
    yarn run build

## Developer Mode (Watch)

    yarn start

In a second terminal...

    yarn run serve

Open http://localhost:8080/edu.html
