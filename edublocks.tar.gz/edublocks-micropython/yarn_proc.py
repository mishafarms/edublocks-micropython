import yaml
import re


class NestedDictNavigator:
    def __init__(self, key, value):
        self.data = {key: value}
        self.key_stack = []  # Stack of keys

    def push(self, key):
        """Go to a deeper level in the nested structure by adding a new key."""
        # Initialize a new dictionary at this level
        self._navigate_to_last_key()[key] = {}

        self.key_stack.append(key)

    def pop(self, levels=1):
        """Go to an upper level in the nested structure by removing the last added keys."""
        for _ in range(levels):
            if self.key_stack:
                self.key_stack.pop()

    def add_key(self, key, value):
        """Add a new key-value pair at the current depth."""
        self._navigate_to_last_key()[key] = value

    def _navigate_to_last_key(self):
        """Navigate to the current depth in the data according to the key stack."""
        data = self.data
        for key in self.key_stack:  # Go till depth-1
            data = data[key]
        return data

    def get_current_data(self):
        """Get the data at the current depth of the nested dictionary."""
        return self._navigate_to_last_key()[self.key_stack[-1]] if self.key_stack else self.data

    def __str__(self):
        return str(self.data)

    def __repr__(self):
        return str(self.data)

    def __getitem__(self, key):
        """Allows instance to be indexed like a dictionary."""
        return self._navigate_to_last_key()[key]

def parse_yarn_lock(filepath):
    init = True
    data = {}
    key = 'None'
    depth = 0

    with open(filepath, 'r') as file:
        for line in file:
            line = line.replace('\n', '')

            if not line:  # skip empty lines
                continue

            if init and line[0] != '"':
                continue
            else:
                init = False

            # Detect package block start
            if line.endswith(':') and line.startswith('"'):
                # we want to start a new dict
                line = line.replace('"', '')
                key, version = line.split(':')[:2]
                data[key] = NestedDictNavigator('mod_version', version)
                depth = 1
            elif line.endswith(':'):
                # this is a new level
                new_key = line.lstrip(' ').split(':')[0]
                data[key].push(new_key)
                depth += 1
            else:
                cur_depth = (len(line) - len(line.lstrip())) // 2
                if cur_depth < depth:
                    # it seems we have left the last level
                    data[key].pop(depth - cur_depth)
                    depth = cur_depth
                elif cur_depth > depth:
                    # looks like we should have pushed
                    print(f"We have a depth problem for key '{key}' depth {depth} line = '{line}'")
                    raise ValueError(f"We have a depth problem for key '{key}'")

                new_key, value = line.lstrip(' ').split(': ')[:2]
                data[key].add_key(new_key, value)

    return data


if __name__ == "__main__":
    # Test the function
    yarn_dict = parse_yarn_lock('yarn.lock')

    for key in yarn_dict:
        try:
            my_data = yarn_dict[key]
            print(f"{key}: mod_version: {yarn_dict[key]['mod_version']} version: {yarn_dict[key]['version']}")
        except KeyError as e:
            print(e)
