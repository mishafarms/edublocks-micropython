"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __assign = (this && this.__assign) || Object.assign || function(t) {
    for (var s, i = 1, n = arguments.length; i < n; i++) {
        s = arguments[i];
        for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
            t[p] = s[p];
    }
    return t;
};
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = y[op[0] & 2 ? "return" : op[0] ? "throw" : "next"]) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [0, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
Object.defineProperty(exports, "__esModule", { value: true });
var React = require("preact");
var preact_1 = require("preact");
var Nav_1 = require("./Nav");
var BlocklyView_1 = require("./BlocklyView");
var PythonView_1 = require("./PythonView");
var TerminalView_1 = require("./TerminalView");
var FileModal_1 = require("./FileModal");
var Status_1 = require("./Status");
var types_1 = require("../types");
var lib_1 = require("../lib");
var SelectModal_1 = require("./SelectModal");
var AdvancedFunctions = ['New Python Script', 'Export', 'Set As Startup Script'];
var ViewModeBlockly = 'blockly';
var ViewModePython = 'python';
var Page = (function (_super) {
    __extends(Page, _super);
    function Page(props) {
        var _this = _super.call(this, props) || this;
        _this.state = {
            connectionStatus: 'disconnected',
            viewMode: ViewModeBlockly,
            terminalOpen: false,
            dirty: true,
            modal: null,
            doc: {
                fileType: types_1.EduBlocksXML,
                dirName: '/user',
                fileName: null,
                xml: null,
                python: null,
                pythonClean: true,
            },
        };
        _this.props.app.onSocketStatusChange(function (connectionStatus) {
            _this.setState({ connectionStatus: connectionStatus });
        });
        return _this;
    }
    Page.prototype.renameDocument = function (fileName) {
        var doc = this.state.doc;
        var fileType = lib_1.getFileType(fileName);
        if (fileType === null) {
            if (doc.fileType === types_1.EduBlocksXML) {
                fileName = fileName + "." + types_1.EduBlocksXML;
                fileType = types_1.EduBlocksXML;
            }
            else if (doc.fileType === types_1.PythonScript) {
                fileName = fileName + "." + types_1.PythonScript;
                fileType = types_1.PythonScript;
            }
            else {
                throw new Error('Invalid type');
            }
        }
        var baseName = lib_1.getBaseName(fileName);
        if (baseName.length === 0) {
            alert('Filename is empty');
            return;
        }
        if (!/^([a-z]|[0-9]|_)+$/.test(baseName)) {
            alert('Filenames can only contain lowercase letters and underscores');
            return;
        }
        if (baseName.charCodeAt(0) >= 48 && baseName.charCodeAt(0) <= 57) {
            alert('Filename must not being with a number');
            return;
        }
        if (fileType === 'xml' && doc.fileType === 'xml') {
            var xmlDoc = __assign({}, doc, { fileType: fileType,
                fileName: fileName });
            this.setState({ doc: xmlDoc });
        }
        if (fileType === 'py' && doc.fileType === 'py') {
            var pyDoc = __assign({}, doc, { fileType: fileType,
                fileName: fileName });
            this.setState({ doc: pyDoc });
        }
        // Convert from XML -> PY
        if (fileType === 'py' && doc.fileType === 'xml') {
            var pyDoc = {
                fileType: fileType,
                dirName: doc.dirName,
                fileName: fileName,
                python: doc.python,
                pythonClean: false,
            };
            this.setState({ doc: pyDoc });
        }
        // Convert from PY -> XML
        if (fileType === 'xml' && doc.fileType === 'py') {
            alert('Cannot convert a Python document to an EduBlocks document');
            return;
        }
        if (fileType === types_1.PythonScript) {
            this.switchView(ViewModePython);
        }
        else {
            this.switchView(ViewModeBlockly);
        }
    };
    Page.prototype.readBlocklyContents = function (dirName, fileName, xml, dirty) {
        var doc = {
            fileType: types_1.EduBlocksXML,
            dirName: dirName,
            fileName: fileName,
            xml: xml,
            python: null,
            pythonClean: true,
        };
        this.setState({ doc: doc, dirty: dirty });
        this.switchView(ViewModeBlockly);
    };
    Page.prototype.readPythonContents = function (dirName, fileName, python, dirty) {
        if (this.state.doc.python === python) {
            return;
        }
        var doc = {
            fileType: types_1.PythonScript,
            dirName: dirName,
            fileName: fileName,
            xml: null,
            python: python,
            pythonClean: false,
        };
        this.setState({ doc: doc, dirty: dirty });
        this.switchView(ViewModePython);
    };
    Page.prototype.updateFromBlockly = function (xml, python) {
        var doc = this.state.doc;
        // Only if the XML is changed do we need to set the dirty flag.
        // Otherwise what is already saved on the device is assumed to be up-to-date.
        var xmlChanged = doc.fileType === types_1.EduBlocksXML && doc.xml !== xml;
        if (doc.fileType === types_1.EduBlocksXML &&
            doc.xml === xml &&
            doc.python === python) {
            return;
        }
        if (doc.python !== python && !doc.pythonClean) {
            alert('Python changes have been overwritten!');
        }
        var newDoc = {
            fileType: types_1.EduBlocksXML,
            dirName: doc.dirName,
            fileName: doc.fileName,
            xml: xml,
            python: python,
            pythonClean: true,
        };
        this.setState({ doc: newDoc });
        if (xmlChanged) {
            this.setState({ dirty: xmlChanged });
        }
    };
    Page.prototype.updateFromPython = function (python) {
        if (this.state.doc.python === python) {
            return;
        }
        console.log('updateFromPython', python);
        var doc = __assign({}, this.state.doc, { python: python, pythonClean: false });
        this.setState({ doc: doc, dirty: true });
    };
    Page.prototype.newEduBlocksScript = function () {
        var doc = {
            fileType: types_1.EduBlocksXML,
            dirName: '/user',
            fileName: null,
            xml: null,
            python: null,
            pythonClean: true,
        };
        this.setState({ doc: doc, dirty: true });
        this.switchView('blockly');
    };
    Page.prototype.newPythonScript = function () {
        var doc = {
            fileType: types_1.PythonScript,
            dirName: '/user',
            fileName: null,
            python: null,
            pythonClean: false,
        };
        this.setState({ doc: doc, dirty: true });
        this.switchView('python');
    };
    Page.prototype.componentDidMount = function () {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                return [2 /*return*/];
            });
        });
    };
    Page.prototype.toggleView = function () {
        switch (this.state.viewMode) {
            case ViewModeBlockly:
                return this.switchView(ViewModePython);
            case ViewModePython:
                return this.switchView(ViewModeBlockly);
        }
    };
    Page.prototype.switchView = function (viewMode) {
        switch (viewMode) {
            case ViewModeBlockly:
                if (this.state.doc.fileType === types_1.PythonScript) {
                    alert('Block view not available');
                    return 0;
                }
                this.setState({ viewMode: 'blockly' });
                return 0;
            case ViewModePython:
                this.setState({ viewMode: 'python' });
                return 0;
        }
    };
    Page.prototype.run = function () {
        return __awaiter(this, void 0, void 0, function () {
            var _this = this;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.save()];
                    case 1:
                        if (_a.sent()) {
                            // this.props.app.runCode(this.state.doc.python || '');
                            this.props.app.runDoc(this.state.doc);
                            this.setState({ terminalOpen: true });
                            this.terminalView.focus();
                            setTimeout(function () { return _this.terminalView.focus(); }, 250);
                        }
                        return [2 /*return*/];
                }
            });
        });
    };
    Page.prototype.openTerminal = function () {
        var _this = this;
        this.setState({ terminalOpen: true });
        this.terminalView.focus();
        setTimeout(function () { return _this.terminalView.focus(); }, 250);
    };
    Page.prototype.openFileListModal = function () {
        this.setState({ modal: 'File' });
    };
    Page.prototype.closeFileListModal = function () {
        this.setState({ modal: null });
    };
    Page.prototype.handleFileContents = function (dirName, fileName, contents) {
        var sample = false;
        if (dirName === '/samples') {
            dirName = '/user';
            sample = true;
        }
        switch (lib_1.getFileType(fileName)) {
            case types_1.EduBlocksXML:
                this.readBlocklyContents(dirName, fileName, contents, sample);
                return 0;
            case types_1.PythonScript:
                this.readPythonContents(dirName, fileName, contents, sample);
                return 0;
            case null:
                alert('Unknown file type');
                return 0;
        }
    };
    Page.prototype.onBlocklyChange = function (xml, python) {
        this.updateFromBlockly(xml, python);
    };
    Page.prototype.onPythonChange = function (python) {
        this.updateFromPython(python);
    };
    Page.prototype.checkReadyToSave = function () {
        if (!this.state.doc.fileName) {
            var fileName = prompt('Enter filename');
            if (fileName) {
                this.renameDocument(fileName);
            }
        }
        if (!this.state.doc.fileName) {
            alert('You must specify a filename in order to save');
            return false;
        }
        return true;
    };
    Page.prototype.save = function () {
        return __awaiter(this, void 0, void 0, function () {
            var err_1;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        if (!this.state.dirty) {
                            return [2 /*return*/, true];
                        }
                        if (!this.checkReadyToSave()) return [3 /*break*/, 5];
                        _a.label = 1;
                    case 1:
                        _a.trys.push([1, 3, , 4]);
                        return [4 /*yield*/, this.props.app.save(this.state.doc)];
                    case 2:
                        _a.sent();
                        this.setState({ dirty: false });
                        return [3 /*break*/, 4];
                    case 3:
                        err_1 = _a.sent();
                        if (err_1 instanceof Error) {
                            alert(err_1.message);
                        }
                        return [3 /*break*/, 4];
                    case 4: return [2 /*return*/, true];
                    case 5: return [2 /*return*/, false];
                }
            });
        });
    };
    Page.prototype.onFileSelected = function (result) {
        return __awaiter(this, void 0, void 0, function () {
            var dirName, fileName, contents;
            return __generator(this, function (_a) {
                this.closeFileListModal();
                if (result) {
                    dirName = result.dirName, fileName = result.fileName, contents = result.contents;
                    this.handleFileContents(dirName, fileName, contents);
                }
                return [2 /*return*/];
            });
        });
    };
    Page.prototype.onSelectFile = function (file) {
        return __awaiter(this, void 0, void 0, function () {
            var fileName, fileData;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        fileName = file.name;
                        return [4 /*yield*/, lib_1.readText(file)];
                    case 1:
                        fileData = _a.sent();
                        this.handleFileContents('/user', fileName, fileData);
                        this.setState({ dirty: true });
                        return [2 /*return*/];
                }
            });
        });
    };
    Page.prototype.onTerminalClose = function () {
        this.setState({ terminalOpen: false });
    };
    Page.prototype.getXml = function () {
        if (this.state.doc.fileType === 'xml') {
            return this.state.doc.xml || '';
        }
        return '';
    };
    Page.prototype.getDocumentFilePath = function () {
        var doc = this.state.doc;
        return lib_1.joinDirNameAndFileName(doc.dirName, doc.fileName);
    };
    Page.prototype.export = function () {
        var doc = this.state.doc;
        var fileName = doc.fileName || "untitled." + doc.fileType;
        if (doc.fileType === types_1.EduBlocksXML) {
            var blob = new Blob([doc.xml], { type: 'text/xml' });
            saveAs(blob, fileName);
        }
        if (doc.fileType === types_1.PythonScript) {
            var blob = new Blob([doc.python], { type: 'text/xml' });
            saveAs(blob, fileName);
        }
    };
    Page.prototype.getAdvancedFunctionList = function () {
        return AdvancedFunctions.map(function (func) { return ({
            label: func,
            obj: func,
        }); });
    };
    Page.prototype.openAdvancedFunctionDialog = function () {
        this.setState({ modal: 'Functions' });
    };
    Page.prototype.closeAdvancedFunctionDialog = function () {
        this.setState({ modal: null });
    };
    Page.prototype.runAdvancedFunction = function (func) {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        if (func === 'New Python Script') {
                            this.newPythonScript();
                        }
                        if (func === 'Export') {
                            this.export();
                        }
                        if (!(func === 'Set As Startup Script')) return [3 /*break*/, 3];
                        return [4 /*yield*/, this.save()];
                    case 1:
                        if (!_a.sent()) return [3 /*break*/, 3];
                        return [4 /*yield*/, this.props.app.setStartup(this.state.doc)];
                    case 2:
                        _a.sent();
                        _a.label = 3;
                    case 3:
                        this.closeAdvancedFunctionDialog();
                        return [2 /*return*/];
                }
            });
        });
    };
    Page.prototype.render = function () {
        var _this = this;
        return (React.createElement("div", { class: "Page" },
            React.createElement(Nav_1.default, { onFunction: function () { return _this.openAdvancedFunctionDialog(); }, onRun: function () { return _this.run(); }, onTerminal: function () { return _this.openTerminal(); }, onDownloadPython: function () { }, onOpen: function () { return _this.openFileListModal(); }, onSave: function () { return _this.save(); }, onNew: function () { return _this.newEduBlocksScript(); }, onSelectFile: function (file) { return _this.onSelectFile(file); } }),
            React.createElement(Status_1.default, { connectionStatus: this.state.connectionStatus, doc: this.state.doc, sync: this.state.doc.pythonClean, onChangeName: function (file) { return _this.renameDocument(file); } }),
            React.createElement("section", { id: "workspace" },
                React.createElement("button", { id: "toggleViewButton", onClick: function () { return _this.toggleView(); } }, this.state.viewMode),
                React.createElement(BlocklyView_1.default, { ref: function (c) { return _this.blocklyView = c; }, visible: this.state.viewMode === 'blockly', xml: this.getXml(), onChange: function (xml, python) { return _this.onBlocklyChange(xml, python); } }),
                React.createElement(PythonView_1.default, { ref: function (c) { return _this.pythonView = c; }, visible: this.state.viewMode === 'python', python: this.state.doc.python, onChange: function (python) { return _this.onPythonChange(python); } })),
            React.createElement(TerminalView_1.default, { ref: function (c) { return _this.terminalView = c; }, visible: this.state.terminalOpen, onClose: function () { return _this.onTerminalClose(); } }),
            this.state.modal === 'File' &&
                React.createElement(FileModal_1.default, { app: this.props.app, onSelect: function (file) { return _this.onFileSelected(file); } }),
            this.state.modal === 'Functions' &&
                React.createElement(SelectModal_1.default, { title: "Advanced Functions", selectLabel: "Go", buttons: [], options: this.getAdvancedFunctionList(), onSelect: function (func) { return _this.runAdvancedFunction(func.label); }, onButtonClick: function (key) { return key === 'close' && _this.closeAdvancedFunctionDialog(); } })));
    };
    return Page;
}(preact_1.Component));
exports.default = Page;
