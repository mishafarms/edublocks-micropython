"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
var React = require("preact");
var preact_1 = require("preact");
var TerminalView = (function (_super) {
    __extends(TerminalView, _super);
    function TerminalView() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    TerminalView.prototype.componentDidMount = function () {
        var _this = this;
        if (!this.termDiv) {
            throw new Error('No term');
        }
        var _a = this.calculateSize(), x = _a[0], y = _a[1];
        this.term = new Terminal({
            cols: x,
            rows: y,
            useStyle: true,
            screenKeys: true,
            cursorBlink: false,
        });
        this.term.open(this.termDiv);
        this.term.on('data', function (data) {
            _this.onDataHandler(data);
            if (data.length === 1 && data.charCodeAt(0) === 27) {
                _this.props.onClose();
            }
        });
        this.term.write('\x1b[31mWelcome to EduBlocks!\x1b[m\r\n');
        this.term.write('Press [ESC] to exit the terminal\r\n');
        window.addEventListener('resize', function () { return _this.resizeTerminal; });
    };
    TerminalView.prototype.calculateSize = function () {
        if (!this.termDiv) {
            throw new Error('No term');
        }
        var cols = Math.max(80, Math.min(300, this.termDiv.clientWidth / 6.7)) | 0;
        var rows = Math.max(10, Math.min(80, this.termDiv.clientHeight / 20.5)) | 0;
        return [cols, rows];
    };
    TerminalView.prototype.resizeTerminal = function () {
        if (!this.termDiv) {
            throw new Error('No term');
        }
        var _a = this.calculateSize(), x = _a[0], y = _a[1];
        this.term.resize(x, y);
    };
    TerminalView.prototype.componentDidUpdate = function (prevProps) {
        if (!prevProps.visible && this.props.visible) {
            this.resizeTerminal();
        }
    };
    TerminalView.prototype.focus = function () {
        if (!this.term) {
            return;
        }
        this.term.focus();
        this.term.element.focus();
    };
    TerminalView.prototype.write = function (s) {
        this.term.write(s);
    };
    TerminalView.prototype.onData = function (handler) {
        this.onDataHandler = handler;
    };
    TerminalView.prototype.render = function () {
        var _this = this;
        return (React.createElement("div", { style: { display: this.props.visible ? 'block' : 'none' }, class: "TerminalView" },
            React.createElement("div", { class: "TerminalView__term", ref: function (div) { return _this.termDiv = div; } })));
    };
    return TerminalView;
}(preact_1.Component));
exports.default = TerminalView;
