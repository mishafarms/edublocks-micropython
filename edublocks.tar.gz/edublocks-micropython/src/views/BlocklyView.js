"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
var React = require("preact");
var preact_1 = require("preact");
var blocks_1 = require("../blocks");
var BlocklyView = (function (_super) {
    __extends(BlocklyView, _super);
    function BlocklyView(props) {
        var _this = _super.call(this, props) || this;
        _this.xml = null;
        return _this;
    }
    BlocklyView.prototype.componentWillReceiveProps = function (nextProps) {
        if (nextProps.visible) {
            if (this.xml !== nextProps.xml) {
                this.setXml(nextProps.xml);
            }
        }
    };
    BlocklyView.prototype.componentDidMount = function () {
        var _this = this;
        if (this.blocklyDiv) {
            var toolboxText = blocks_1.getToolBoxXml();
            var toolboxXml = Blockly.Xml.textToDom(toolboxText);
            var workspace = Blockly.inject(this.blocklyDiv, {
                media: 'blockly/media/',
                toolbox: toolboxXml,
                zoom: { controls: true,
                    wheel: true },
                oneBasedIndex: true,
            });
            workspace.addChangeListener(function () {
                var xml = _this.getXml();
                var python = _this.getPython();
                _this.xml = xml;
                _this.props.onChange(xml, python);
            });
            Blockly.svgResize(workspace);
        }
        Blockly.Python.addReservedWords('otto9,Otto,gestures,songs,notes,mouths,TouchPin,');
    };
    BlocklyView.prototype.getXml = function () {
        var xml = Blockly.Xml.workspaceToDom(Blockly.mainWorkspace);
        return Blockly.Xml.domToPrettyText(xml);
    };
    BlocklyView.prototype.getPython = function () {
        return Blockly.Python.workspaceToCode(Blockly.mainWorkspace);
    };
    BlocklyView.prototype.setXml = function (xml) {
        Blockly.mainWorkspace.clear();
        if (typeof xml === 'string') {
            if (xml === '') {
                xml = '<xml xmlns="https://developers.google.com/blockly/xml">' +
                    '</xml>';
            }
            var textToDom = Blockly.Xml.textToDom(xml);
            Blockly.Xml.domToWorkspace(textToDom, Blockly.mainWorkspace);
            var python = this.getPython();
            this.props.onChange(xml, python);
        }
    };
    BlocklyView.prototype.render = function () {
        var _this = this;
        return (React.createElement("div", { style: { visibility: this.props.visible ? 'visible' : 'hidden' }, id: "blockly", ref: function (div) { return _this.blocklyDiv = div; } }));
    };
    return BlocklyView;
}(preact_1.Component));
exports.default = BlocklyView;
