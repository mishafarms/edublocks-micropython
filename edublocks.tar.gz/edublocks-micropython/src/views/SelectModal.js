"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
var React = require("preact");
var preact_1 = require("preact");
var SelectModal = (function (_super) {
    __extends(SelectModal, _super);
    function SelectModal() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    SelectModal.prototype.getButtons = function () {
        return this.props.buttons.concat([
            { key: 'close', label: 'Close', position: 'right' },
        ]);
    };
    SelectModal.prototype.render = function () {
        var _this = this;
        var getOptions = function () { return _this.props.options.map(function (option) { return ([
            React.createElement("div", { class: "SelectModal__cell SelectModal__cell--text" },
                React.createElement("span", null, option.label)),
            React.createElement("div", { class: "SelectModal__cell SelectModal__cell--action" },
                React.createElement("button", { onClick: function () { return _this.props.onSelect(option); } }, _this.props.selectLabel)),
        ]); }); };
        return (React.createElement("div", { class: "SelectModal modal" },
            React.createElement("input", { id: "modal_1", type: "checkbox", disabled: true, checked: true }),
            React.createElement("label", { for: "modal_1", class: "overlay" }),
            React.createElement("article", { class: "SelectModel__container" },
                React.createElement("header", { class: "SelectModal__header" },
                    React.createElement("h3", null, this.props.title),
                    React.createElement("a", { class: "SelectModal__close close", onClick: function () { return _this.props.onButtonClick('close'); } }, "\u00D7")),
                React.createElement("section", { class: "SelectModel__content" },
                    React.createElement("div", { class: "SelectModal__grid" }, getOptions())),
                React.createElement("footer", { class: "SelectModal__buttons" }, this.getButtons().map(function (button) {
                    return (React.createElement("button", { style: (_a = { float: button.position }, _a["margin-" + (button.position === 'left' ? 'right' : 'left')] = '8px', _a), onClick: function () { return _this.props.onButtonClick(button.key); } }, button.label));
                    var _a;
                })))));
    };
    return SelectModal;
}(preact_1.Component));
exports.default = SelectModal;
