"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var React = require("preact");
function Nav(props) {
    function onFileSelected(target) {
        props.onSelectFile(target.files[0]);
    }
    return (React.createElement("nav", { class: "Nav" },
        React.createElement("a", { class: "brand" },
            React.createElement("img", { class: "logo", src: "images/logo.png" })),
        React.createElement("a", { class: "brand" },
            React.createElement("img", { class: "logo", src: "images/logo_built_on_knockout.png" })),
        React.createElement("div", { class: "menu" },
            React.createElement("label", { class: "button", for: "myfile" }, "Upload a file:"),
            React.createElement("input", { type: "file", value: "", id: "myfile", class: "file", onChange: function (e) { return onFileSelected(e.target); } }),
            React.createElement("a", { class: "button", title: "Functions", href: "javascript:void(0)", onClick: function () { return props.onFunction(); } }, "Functions"),
            React.createElement("a", { class: "button icon-plus", title: "New", href: "javascript:void(0)", onClick: function () { return props.onNew(); } }, "New"),
            React.createElement("a", { class: "button icon-folder-open", title: "Open a file", href: "javascript:void(0)", onClick: function () { return props.onOpen(); } }, "Open"),
            React.createElement("a", { class: "button icon-floppy", title: "Save a file", href: "javascript:void(0)", onClick: function () { return props.onSave(); } }, "Save"),
            React.createElement("a", { class: "button icon-play", title: "Run your code", href: "javascript:void(0)", onClick: function () { return props.onRun(); } }, "Run"),
            React.createElement("a", { class: "button icon-desktop", title: "Terminal", href: "javascript:void(0)", onClick: function () { return props.onTerminal(); } }, "WebREPL >>>"))));
}
exports.default = Nav;
