"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var React = require("preact");
var lib_1 = require("../lib");
function Status(props) {
    function changeName() {
        var fileName = prompt('Enter new filename', props.doc.fileName || '');
        if (fileName) {
            props.onChangeName(fileName);
        }
    }
    function getDocumentFilePath() {
        var doc = props.doc;
        return lib_1.joinDirNameAndFileName(doc.dirName, doc.fileName);
    }
    function getFileTypeString() {
        switch (props.doc.fileType) {
            case 'xml':
                return 'Blockly Script';
            case 'py':
                return 'Python Script';
        }
    }
    return (React.createElement("div", { class: "Status" },
        React.createElement("span", { class: "Status__filename", onClick: function () { return changeName(); } },
            getDocumentFilePath() || '[New file]',
            " (",
            getFileTypeString(),
            ")"),
        !props.sync ? React.createElement("span", { class: "Status__sync" }, "(Not in sync with block view)") : null,
        React.createElement("span", { class: "Status__connection Status__connection--" + props.connectionStatus }, props.connectionStatus)));
}
exports.default = Status;
