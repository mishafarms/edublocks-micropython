"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
function define(Python) {
    Python['import_machine'] = function () {
        Blockly.Python.definitions_['import_machine'] = 'import machine\n';
        return '';
    };
    Python['import_neopixel'] = function () {
        Blockly.Python.definitions_['import_neopixel'] = 'import neopixel\n';
        return '';
    };
    Python['pin_in_declare'] = function (block) {
        var pin_number = Blockly.Python.valueToCode(block, 'pin_number', Blockly.Python.ORDER_ATOMIC);
        var pull_up_down = block.getFieldValue('pull_up_down');
        Blockly.Python.definitions_['import_machine'] = 'import machine\n';
        var code = "machine.Pin(" + pin_number + ", machine.Pin.IN, machine.Pin." + pull_up_down + ")\n";
        return [code, Blockly.Python.ORDER_ATOMIC];
    };
    Python['pin_out_declare'] = function (block) {
        var pin_number = Blockly.Python.valueToCode(block, 'pin_number', Blockly.Python.ORDER_ATOMIC);
        Blockly.Python.definitions_['import_machine'] = 'import machine\n';
        var code = "machine.Pin(" + pin_number + ", machine.Pin.OUT)\n";
        return [code, Blockly.Python.ORDER_ATOMIC];
    };
    Python['pin_value_get'] = function (block) {
        var pin_name = Blockly.Python.valueToCode(block, 'pin_name', Blockly.Python.ORDER_ATOMIC);
        Blockly.Python.definitions_['import_machine'] = 'import machine\n';
        var code = pin_name + ".value()\n";
        return [code, Blockly.Python.ORDER_ATOMIC];
    };
    Python['pin_value_set'] = function (block) {
        var pin_name = Blockly.Python.valueToCode(block, 'pin_name', Blockly.Python.ORDER_ATOMIC);
        var value = Blockly.Python.valueToCode(block, 'value', Blockly.Python.ORDER_ATOMIC);
        Blockly.Python.definitions_['import_machine'] = 'import machine\n';
        var code = pin_name + ".value(" + value + ")\n";
        return code;
    };
    Python['neopixel_declare'] = function (block) {
        var pin_number = Blockly.Python.valueToCode(block, 'pin_number', Blockly.Python.ORDER_ATOMIC);
        var length = Blockly.Python.valueToCode(block, 'length', Blockly.Python.ORDER_ATOMIC);
        Blockly.Python.definitions_['import_neopixel'] = 'import neopixel\n';
        var code = "neopixel.NeoPixel(" + pin_number + ", " + length + ")\n";
        return [code, Blockly.Python.ORDER_ATOMIC];
    };
    Python['led_colour_set'] = function (block) {
        var functionName = Blockly.Python.provideFunction_('convert_rgb', ['def ' + Blockly.Python.FUNCTION_NAME_PLACEHOLDER_ + '(colour):',
            '  if isinstance(colour, str) and len(colour) == 7:',
            '     r = int(colour[1:3], 16)',
            '     g = int(colour[3:5], 16)',
            '     b = int(colour[5:7], 16)',
            '  elif isinstance(colour, tuple):',
            '    r, g, b = colour',
            '  else:',
            '     r, g, b = 0, 0, 0',
            '  return r, g, b']);
        var np_name = Blockly.Python.valueToCode(block, 'np_name', Blockly.Python.ORDER_ATOMIC);
        var index = Blockly.Python.getAdjustedInt(block, 'index');
        var colour1 = Blockly.Python.valueToCode(block, 'colour1', Blockly.Python.ORDER_ATOMIC);
        Blockly.Python.definitions_['import_neopixel'] = 'import neopixel\n';
        var code = np_name + '[' + index + '] = ' + functionName + '(' + colour1 + ') # Colour = ' + colour1 + '\n';
        return code;
    };
    Python['neopixel_write'] = function (block) {
        var np_name = Blockly.Python.valueToCode(block, 'np_name', Blockly.Python.ORDER_ATOMIC);
        Blockly.Python.definitions_['import_neopixel'] = 'import neopixel\n';
        return np_name + ".write()\n";
    };
}
exports.default = define;
