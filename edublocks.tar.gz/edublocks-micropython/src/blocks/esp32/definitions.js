"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
function define(Blocks) {
    Blocks['import_machine'] = {
        init: function () {
            this.appendDummyInput()
                .appendField('import machine');
            this.setPreviousStatement(true, null);
            this.setNextStatement(true, null);
            this.setColour(336);
            this.setTooltip('Imports the machine library for GPIO access.');
            this.setHelpUrl('http://www.example.com/');
        },
    };
    Blocks['import_neopixel'] = {
        init: function () {
            this.appendDummyInput()
                .appendField('import neopixel');
            this.setPreviousStatement(true, null);
            this.setNextStatement(true, null);
            this.setColour(336);
            this.setTooltip('Imports the neopixel library for LED control.');
            this.setHelpUrl('http://www.example.com/');
        },
    };
    Blocks['pin_in_declare'] = {
        init: function () {
            this.appendDummyInput()
                .appendField('machine.Pin(');
            this.appendValueInput('pin_number').setCheck('Number');
            this.appendDummyInput()
                .appendField(', machine.Pin.IN, machine.Pin.')
                .appendField(new Blockly.FieldDropdown([['PULL_UP', 'PULL_UP'], ['PULL_DOWN', 'PULL_DOWN']]), 'pull_up_down')
                .appendField(')');
            this.setInputsInline(true);
            this.setOutput(true, 'Number');
            this.setColour(120);
            this.setTooltip('Declare an input pin');
            this.setHelpUrl('http://www.example.com/');
        },
    };
    Blocks['pin_out_declare'] = {
        init: function () {
            this.appendDummyInput()
                .appendField('machine.Pin(');
            this.appendValueInput('pin_number').setCheck('Number');
            this.appendDummyInput()
                .appendField(', machine.Pin.OUT)');
            this.setInputsInline(true);
            this.setOutput(true, 'Number');
            this.setColour(120);
            this.setTooltip('Declare an output pin');
            this.setHelpUrl('http://www.example.com/');
        },
    };
    Blocks['pin_value_get'] = {
        init: function () {
            this.appendValueInput('pin_name').setCheck('String');
            this.appendDummyInput()
                .appendField('.value()');
            this.setInputsInline(true);
            this.setOutput(true, null);
            this.setColour(120);
            this.setTooltip('Get pin value');
            this.setHelpUrl('http://www.example.com/');
        },
    };
    Blocks['pin_value_set'] = {
        init: function () {
            this.appendValueInput('pin_name').setCheck('String');
            this.appendDummyInput()
                .appendField('.value(');
            this.appendValueInput('value');
            this.appendDummyInput()
                .appendField(')');
            this.setPreviousStatement(true, null);
            this.setNextStatement(true, null);
            this.setColour(120);
            this.setTooltip('Set pin value');
            this.setHelpUrl('http://www.example.com/');
        },
    };
    Blocks['neopixel_declare'] = {
        init: function () {
            this.appendDummyInput()
                .appendField('neopixel.NeoPixel(');
            this.appendValueInput('pin_number').setCheck('Number');
            this.appendDummyInput()
                .appendField(', ');
            this.appendValueInput('length').setCheck('Number');
            this.appendDummyInput()
                .appendField(')');
            this.setInputsInline(true);
            this.setOutput(true, null);
            this.setColour(120);
            this.setTooltip('Declare NeoPixel strip');
            this.setHelpUrl('http://www.example.com/');
        },
    };
    Blocks['led_colour_set'] = {
        init: function () {
            this.appendValueInput('np_name').setCheck('String');
            this.appendDummyInput()
                .appendField('[');
            this.appendValueInput('index').setCheck('Number');
            this.appendDummyInput()
                .appendField('] =');
            this.appendValueInput('colour1')
                .setAlign(Blockly.ALIGN_RIGHT);
            this.setInputsInline(true);
            this.setPreviousStatement(true, null);
            this.setNextStatement(true, null);
            this.setColour(120);
            this.setTooltip('Set LED colour');
            this.setHelpUrl('http://www.example.com/');
        },
    };
    Blocks['neopixel_write'] = {
        init: function () {
            this.appendValueInput('np_name').setCheck('String');
            this.appendDummyInput()
                .appendField('.write()');
            this.setPreviousStatement(true, null);
            this.setNextStatement(true, null);
            this.setColour(120);
            this.setTooltip('Write the colours to the LED strip.');
            this.setHelpUrl('http://www.example.com/');
        },
    };
}
exports.default = define;
