"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var fs = require("fs");
var path = require("path");
var toolBoxXml = '';
toolBoxXml += '<xml xmlns="https://developers.google.com/blockly/xml">';
var definitions_1 = require("./basic/definitions");
var generators_1 = require("./basic/generators");
definitions_1.default(Blockly.Blocks);
generators_1.default(Blockly.Python);
toolBoxXml += fs.readFileSync(path.join(__dirname, '..', '..', 'src', 'blocks', 'basic', 'toolbox.xml'));
var definitions_2 = require("./esp32/definitions");
var generators_2 = require("./esp32/generators");
definitions_2.default(Blockly.Blocks);
generators_2.default(Blockly.Python);
toolBoxXml += fs.readFileSync(path.join(__dirname, '..', '..', 'src', 'blocks', 'esp32', 'toolbox.xml'));
var definitions_3 = require("./otto/definitions");
var generators_3 = require("./otto/generators");
definitions_3.default(Blockly.Blocks);
generators_3.default(Blockly.Python);
toolBoxXml += fs.readFileSync(path.join(__dirname, '..', '..', 'src', 'blocks', 'otto', 'toolbox.xml'));
// add the builtin blocks
toolBoxXml += fs.readFileSync(path.join(__dirname, '..', '..', 'src', 'blocks', 'builtin', 'toolbox.xml'));
// add variables and functions to the end
toolBoxXml += '<category name="Variables" custom="VARIABLE" colour="330">\n</category>\n';
toolBoxXml += '<category name="Functions" custom="PROCEDURE"  colour="290">\n</category>\n';
// import gpiozeroDefs from './gpiozero/definitions';
// import gpiozeroGens from './gpiozero/generators';
// gpiozeroDefs(Blockly.Blocks);
// gpiozeroGens(Blockly.Python as any);
// toolBoxXml += fs.readFileSync(path.join(__dirname, '..', '..', 'src', 'blocks', 'gpiozero', 'toolbox.xml'));
// import advancedDefs from './advanced/definitions';
// import advancedGens from './advanced/generators';
// advancedDefs(Blockly.Blocks);
// advancedGens(Blockly.Python as any);
// toolBoxXml += fs.readFileSync(path.join(__dirname, '..', '..', 'src', 'blocks', 'advanced', 'toolbox.xml'));
toolBoxXml += '</xml>';
function getToolBoxXml() {
    return toolBoxXml;
}
exports.getToolBoxXml = getToolBoxXml;
