"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.EduBlocksXML = 'xml';
exports.PythonScript = 'py';
