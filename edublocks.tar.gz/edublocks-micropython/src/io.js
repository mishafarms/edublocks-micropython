"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
function getIo() {
    return getWebIo();
}
exports.default = getIo;
function getWebIo() {
    /**
     * @param {string} text
     */
    function saveFile(text, _1, _2) {
        var blob = new Blob([text], { type: 'text/xml;charset=utf-8' });
        saveAs(blob, prompt('Enter filename...') || 'unamed.xml');
        return Promise.resolve(null);
    }
    return {
        saveFile: saveFile,
    };
}
