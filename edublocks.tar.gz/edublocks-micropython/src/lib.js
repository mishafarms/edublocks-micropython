"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var types_1 = require("./types");
exports.sleep = function (ms) {
    return new Promise(function (resolve) {
        setTimeout(resolve, ms);
    });
};
exports.readArrayBuffer = function (blob) {
    return new Promise(function (resolve, reject) {
        var reader = new FileReader();
        reader.onload = function (e) {
            resolve(e.target.result);
        };
        reader.readAsArrayBuffer(blob);
    });
};
exports.readText = function (blob) {
    return new Promise(function (resolve, reject) {
        var reader = new FileReader();
        reader.onload = function (e) {
            resolve(e.target.result);
        };
        reader.readAsText(blob);
    });
};
exports.joinDirNameAndFileName = function (dirName, fileName) {
    if (fileName === null) {
        return null;
    }
    return (dirName + "/" + fileName).replace(/\/\//g, '/');
};
function getFileType(file) {
    if (file.indexOf('.xml') === file.length - 4) {
        return types_1.EduBlocksXML;
    }
    if (file.indexOf('.py') === file.length - 3) {
        return types_1.PythonScript;
    }
    return null;
}
exports.getFileType = getFileType;
function getBaseName(fileName) {
    if (fileName.indexOf('.') === -1) {
        return fileName;
    }
    return fileName.split('.').slice(0, -1).join('.');
}
exports.getBaseName = getBaseName;
