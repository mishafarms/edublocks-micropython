window.mainPage = '/edu.html';
window.mainTitle = 'EduBlocks';
